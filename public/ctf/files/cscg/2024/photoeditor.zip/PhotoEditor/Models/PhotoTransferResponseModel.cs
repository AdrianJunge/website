namespace PhotoEditor.Models;

public class PhotoTransferResponseModel
{
    public string? Base64Blob { get; set; }

    public string? Error { get; set; }

}
