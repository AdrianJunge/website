#!/bin/bash

nginx -g 'daemon off;' &
node app.js;

# Keep the docker up
tail -f /dev/null
